#!/usr/bin/env python3
"""
Script de configuración automática para la base de datos
Este script crea la base de datos y la tabla de Alumnos
"""

import mysql.connector
from mysql.connector import Error
import getpass

def configurar_base_datos():
    """
    Configura la base de datos universidad_db y crea la tabla Alumnos
    """
    print("=" * 70)
    print("🔧 CONFIGURACIÓN DE BASE DE DATOS - API SOAP Alumnos")
    print("=" * 70)
    print()
    
    # Solicitar credenciales al usuario
    print("Por favor, ingresa tus credenciales de MySQL:")
    db_user = input("Usuario de MySQL [root]: ").strip() or "root"
    db_password = getpass.getpass("Contraseña de MySQL: ")
    db_host = input("Host de MySQL [localhost]: ").strip() or "localhost"
    
    print()
    print("Conectando a MySQL...")
    
    try:
        # Conectar a MySQL sin especificar base de datos
        conexion = mysql.connector.connect(
            host=db_host,
            user=db_user,
            password=db_password
        )
        
        if conexion.is_connected():
            print("✓ Conexión exitosa a MySQL")
            cursor = conexion.cursor()
            
            # Crear base de datos
            print("\n📦 Creando base de datos 'universidad_db'...")
            cursor.execute("CREATE DATABASE IF NOT EXISTS universidad_db")
            print("✓ Base de datos creada/verificada")
            
            # Usar la base de datos
            cursor.execute("USE universidad_db")
            
            # Crear tabla Alumnos
            print("\n📋 Creando tabla 'Alumnos'...")
            crear_tabla_query = """
            CREATE TABLE IF NOT EXISTS Alumnos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(100) NOT NULL,
                matricula VARCHAR(50) NOT NULL UNIQUE,
                carrera VARCHAR(100) NOT NULL,
                fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
            cursor.execute(crear_tabla_query)
            print("✓ Tabla 'Alumnos' creada/verificada")
            
            # Insertar datos de ejemplo
            print("\n👥 Insertando datos de ejemplo...")
            insertar_datos_query = """
            INSERT IGNORE INTO Alumnos (nombre, matricula, carrera) VALUES
            ('Juan Pérez', 'A001', 'Ingeniería en Sistemas'),
            ('María García', 'A002', 'Licenciatura en Administración'),
            ('Carlos López', 'A003', 'Ingeniería Industrial')
            """
            cursor.execute(insertar_datos_query)
            conexion.commit()
            print("✓ Datos de ejemplo insertados")
            
            # Verificar datos
            cursor.execute("SELECT COUNT(*) FROM Alumnos")
            total = cursor.fetchone()[0]
            print(f"\n📊 Total de alumnos en la base de datos: {total}")
            
            cursor.close()
            conexion.close()
            
            print("\n" + "=" * 70)
            print("✅ ¡CONFIGURACIÓN COMPLETADA EXITOSAMENTE!")
            print("=" * 70)
            print()
            print("📝 Ahora actualiza las credenciales en app.py:")
            print(f"   DB_HOST = '{db_host}'")
            print(f"   DB_USER = '{db_user}'")
            print(f"   DB_PASSWORD = '{db_password}'")
            print(f"   DB_NAME = 'universidad_db'")
            print()
            print("🚀 Para iniciar el servidor ejecuta:")
            print("   python3 app.py")
            print("=" * 70)
            
            # Actualizar app.py con las credenciales
            actualizar_app_py(db_host, db_user, db_password)
            
    except Error as e:
        print(f"\n❌ Error al configurar la base de datos: {e}")
        print("\nVerifica que:")
        print("  • MySQL esté en ejecución")
        print("  • Las credenciales sean correctas")
        print("  • Tengas permisos para crear bases de datos")
        return False
    
    return True


def actualizar_app_py(db_host, db_user, db_password):
    """
    Actualiza las credenciales en app.py
    """
    print("\n🔄 Actualizando credenciales en app.py...")
    
    try:
        with open('app.py', 'r', encoding='utf-8') as f:
            contenido = f.read()
        
        # Reemplazar las credenciales
        contenido = contenido.replace("DB_HOST = 'localhost'", f"DB_HOST = '{db_host}'")
        contenido = contenido.replace("DB_USER = 'root'", f"DB_USER = '{db_user}'")
        contenido = contenido.replace("DB_PASSWORD = 'tu_password'", f"DB_PASSWORD = '{db_password}'")
        
        with open('app.py', 'w', encoding='utf-8') as f:
            f.write(contenido)
        
        print("✓ Credenciales actualizadas en app.py")
        
    except Exception as e:
        print(f"⚠️  No se pudo actualizar app.py automáticamente: {e}")
        print("   Por favor, actualiza las credenciales manualmente")


if __name__ == '__main__':
    configurar_base_datos()
