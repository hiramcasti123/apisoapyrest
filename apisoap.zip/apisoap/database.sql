-- Script SQL para crear la base de datos y la tabla de Alumnos
-- Base de datos: universidad_db

-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS universidad_db;

-- Usar la base de datos
USE universidad_db;

-- Crear la tabla Alumnos
CREATE TABLE IF NOT EXISTS Alumnos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    matricula VARCHAR(50) NOT NULL UNIQUE,
    carrera VARCHAR(100) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertar algunos datos de ejemplo (opcional)
INSERT INTO Alumnos (nombre, matricula, carrera) VALUES
('Juan Pérez', 'A001', 'Ingeniería en Sistemas'),
('María García', 'A002', 'Licenciatura en Administración'),
('Carlos López', 'A003', 'Ingeniería Industrial');
