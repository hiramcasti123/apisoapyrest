"""
Cliente de Prueba para API SOAP - Gestión de Alumnos
Este script prueba los métodos SOAP del servicio de alumnos
"""

from zeep import Client
from zeep.exceptions import Fault

# URL del WSDL del servicio
WSDL_URL = 'http://localhost:5001/soap'

def probar_servicio():
    """
    Prueba los métodos del servicio SOAP
    """
    print("=" * 70)
    print("🧪 CLIENTE DE PRUEBA - API SOAP ALUMNOS")
    print("=" * 70)
    
    try:
        # Crear cliente SOAP
        print("\n📡 Conectando al servicio SOAP...")
        client = Client(WSDL_URL)
        print("✅ Conexión exitosa\n")
        
        # Mostrar información del servicio
        print("📋 Servicios disponibles:")
        for service in client.wsdl.services.values():
            print(f"   - {service.name}")
            for port in service.ports.values():
                operations = port.binding._operations.values()
                for operation in operations:
                    print(f"      • {operation.name}")
        print()
        
        # ========================================
        # PRUEBA 1: Listar alumnos existentes
        # ========================================
        print("-" * 70)
        print("🔍 PRUEBA 1: Listar alumnos existentes")
        print("-" * 70)
        
        try:
            resultado = client.service.listar_alumnos()
            print(f"✅ Resultado: {len(resultado)} alumno(s) encontrado(s)")
            for i, nombre in enumerate(resultado, 1):
                print(f"   {i}. {nombre}")
        except Fault as e:
            print(f"❌ Error SOAP: {e}")
        except Exception as e:
            print(f"❌ Error: {e}")
        
        print()
        
        # ========================================
        # PRUEBA 2: Crear un nuevo alumno
        # ========================================
        print("-" * 70)
        print("➕ PRUEBA 2: Crear un nuevo alumno")
        print("-" * 70)
        
        nuevo_nombre = "Pedro Ramírez"
        nueva_matricula = "A999"
        nueva_carrera = "Ingeniería en Computación"
        
        print(f"📝 Datos del nuevo alumno:")
        print(f"   Nombre: {nuevo_nombre}")
        print(f"   Matrícula: {nueva_matricula}")
        print(f"   Carrera: {nueva_carrera}")
        print()
        
        try:
            resultado = client.service.crear_alumno(
                nombre=nuevo_nombre,
                matricula=nueva_matricula,
                carrera=nueva_carrera
            )
            print(f"✅ {resultado}")
        except Fault as e:
            print(f"❌ Error SOAP: {e}")
        except Exception as e:
            print(f"❌ Error: {e}")
        
        print()
        
        # ========================================
        # PRUEBA 3: Listar alumnos después de crear
        # ========================================
        print("-" * 70)
        print("🔍 PRUEBA 3: Listar alumnos después de la creación")
        print("-" * 70)
        
        try:
            resultado = client.service.listar_alumnos()
            print(f"✅ Resultado: {len(resultado)} alumno(s) encontrado(s)")
            for i, nombre in enumerate(resultado, 1):
                print(f"   {i}. {nombre}")
        except Fault as e:
            print(f"❌ Error SOAP: {e}")
        except Exception as e:
            print(f"❌ Error: {e}")
        
        print()
        
        # ========================================
        # PRUEBA 4: Intentar crear alumno duplicado
        # ========================================
        print("-" * 70)
        print("⚠️  PRUEBA 4: Intentar crear alumno con matrícula duplicada")
        print("-" * 70)
        
        try:
            resultado = client.service.crear_alumno(
                nombre="Otro Alumno",
                matricula=nueva_matricula,  # Misma matrícula
                carrera="Otra Carrera"
            )
            print(f"Resultado: {resultado}")
        except Fault as e:
            print(f"❌ Error SOAP esperado (matrícula duplicada): {e}")
        except Exception as e:
            print(f"❌ Error esperado: {e}")
        
        print()
        print("=" * 70)
        print("✅ PRUEBAS COMPLETADAS")
        print("=" * 70)
        
    except Exception as e:
        print(f"\n❌ Error al conectar con el servicio: {e}")
        print("\n💡 Asegúrate de que:")
        print("   1. El servidor está corriendo (python app.py)")
        print("   2. El servicio está disponible en http://localhost:5000/soap")
        print("   3. Tienes instalado zeep: pip install zeep")


if __name__ == '__main__':
    probar_servicio()
