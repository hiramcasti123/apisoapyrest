"""
Cliente de ejemplo para probar la API SOAP de Alumnos
Requiere: pip install zeep
"""

from zeep import Client

def main():
    # URL del WSDL del servicio SOAP
    wsdl_url = 'http://localhost:5000/soap?wsdl'
    
    print("=" * 60)
    print("🧪 Cliente de Prueba - API SOAP Alumnos")
    print("=" * 60)
    
    try:
        # Crear cliente SOAP
        print("\n📡 Conectando al servicio SOAP...")
        client = Client(wsdl_url)
        print("✓ Conexión establecida\n")
        
        # Probar método crear_alumno
        print("=" * 60)
        print("📝 Probando método: crear_alumno")
        print("=" * 60)
        
        resultado = client.service.crear_alumno(
            nombre='Ana Rodríguez',
            matricula='A005',
            carrera='Licenciatura en Informática'
        )
        print(f"Resultado: {resultado}\n")
        
        # Probar método listar_alumnos
        print("=" * 60)
        print("📋 Probando método: listar_alumnos")
        print("=" * 60)
        
        alumnos = client.service.listar_alumnos()
        print(f"Total de alumnos: {len(alumnos)}")
        print("\nLista de alumnos:")
        for i, alumno in enumerate(alumnos, 1):
            print(f"  {i}. {alumno}")
        
        print("\n" + "=" * 60)
        print("✓ Pruebas completadas exitosamente")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\n⚠️  Asegúrate de que el servidor esté ejecutándose:")
        print("   python app.py")


if __name__ == '__main__':
    main()
