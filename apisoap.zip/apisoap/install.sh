#!/bin/bash

# Script de instalación y configuración completa
# Para el proyecto API SOAP - Gestión de Alumnos

echo "======================================================================"
echo "🚀 INSTALACIÓN AUTOMÁTICA - API SOAP Gestión de Alumnos"
echo "======================================================================"
echo ""

# Paso 1: Instalar dependencias
echo "📦 Paso 1/3: Instalando dependencias de Python..."
pip3 install -r requirements.txt
echo ""

# Paso 2: Configurar base de datos
echo "🔧 Paso 2/3: Configurando base de datos MySQL..."
echo "Se te solicitarán tus credenciales de MySQL..."
echo ""
python3 setup_database.py
echo ""

# Paso 3: Información final
echo "======================================================================"
echo "✅ INSTALACIÓN COMPLETADA"
echo "======================================================================"
echo ""
echo "Para iniciar el servidor SOAP ejecuta:"
echo "  python3 app.py"
echo ""
echo "Endpoints disponibles:"
echo "  • Página principal: http://localhost:5000/"
echo "  • Servicio SOAP: http://localhost:5000/soap"
echo "  • WSDL: http://localhost:5000/soap?wsdl"
echo ""
echo "Para probar el servicio:"
echo "  python3 cliente_ejemplo.py"
echo ""
echo "======================================================================"
