"""
API SOAP para gestión de Alumnos - Proyecto Universitario (Versión Compatible)
Autor: Sistema de gestión universitaria
Descripción: Servicio SOAP que permite crear y listar alumnos en una base de datos MySQL
Usando Flask-SOAP para compatibilidad con Python 3.12
"""

from flask import Flask, request, Response
import mysql.connector
from mysql.connector import Error
import xml.etree.ElementTree as ET

# ============================================================================
# CONFIGURACIÓN DE CREDENCIALES DE BASE DE DATOS
# ============================================================================
# ⚠️ IMPORTANTE: Modifica estas variables con tus credenciales locales de MySQL
DB_HOST = 'localhost'
DB_USER = 'root'              # ← Usuario de MySQL
DB_PASSWORD = ''              # ← Contraseña de MySQL (vacía)
DB_NAME = 'universidad_db'
# ============================================================================


def obtener_conexion():
    """
    Establece y retorna una conexión a la base de datos MySQL
    """
    try:
        conexion = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,           # ← Usuario de MySQL
            password=DB_PASSWORD,   # ← Contraseña de MySQL
            database=DB_NAME
        )
        if conexion.is_connected():
            return conexion
    except Error as e:
        print(f"Error al conectar a MySQL: {e}")
        return None


def crear_alumno(nombre, matricula, carrera):
    """
    Crea un nuevo alumno en la base de datos
    
    Parámetros:
        nombre (str): Nombre completo del alumno
        matricula (str): Matrícula única del alumno
        carrera (str): Carrera que cursa el alumno
        
    Retorna:
        str: Mensaje de confirmación o error
    """
    conexion = obtener_conexion()
    
    if conexion is None:
        return "Error: No se pudo conectar a la base de datos"
    
    try:
        cursor = conexion.cursor()
        query = "INSERT INTO Alumnos (nombre, matricula, carrera) VALUES (%s, %s, %s)"
        valores = (nombre, matricula, carrera)
        
        cursor.execute(query, valores)
        conexion.commit()
        
        mensaje = f"Alumno '{nombre}' con matrícula '{matricula}' creado exitosamente"
        
        cursor.close()
        conexion.close()
        
        return mensaje
        
    except Error as e:
        if conexion:
            conexion.close()
        return f"Error al crear alumno: {str(e)}"


def listar_alumnos():
    """
    Lista todos los alumnos registrados en la base de datos
    
    Retorna:
        list: Lista con los nombres de todos los alumnos
    """
    conexion = obtener_conexion()
    
    if conexion is None:
        return ["Error: No se pudo conectar a la base de datos"]
    
    try:
        cursor = conexion.cursor()
        query = "SELECT nombre FROM Alumnos"
        
        cursor.execute(query)
        resultados = cursor.fetchall()
        
        # Extraer solo los nombres de los resultados
        nombres = [fila[0] for fila in resultados]
        
        cursor.close()
        conexion.close()
        
        if not nombres:
            return ["No hay alumnos registrados"]
        
        return nombres
        
    except Error as e:
        if conexion:
            conexion.close()
        return [f"Error al listar alumnos: {str(e)}"]


# Crear la aplicación Flask
app = Flask(__name__)


@app.route('/soap', methods=['POST'])
def soap_service():
    """
    Endpoint para el servicio SOAP
    """
    try:
        # Parsear el XML del request
        soap_request = request.data.decode('utf-8')
        root = ET.fromstring(soap_request)
        
        # Namespaces
        namespaces = {
            'soap': 'http://schemas.xmlsoap.org/soap/envelope/',
            'tns': 'universidad.soap.alumnos'
        }
        
        # Buscar el método llamado
        body = root.find('soap:Body', namespaces)
        
        # Debug: imprimir el request
        print(f"DEBUG - Request recibido: {soap_request[:200]}")
        print(f"DEBUG - Body encontrado: {body is not None}")
        
        # Verificar si es crear_alumno
        crear_elem = body.find('.//tns:crear_alumno', namespaces) or body.find('.//crear_alumno')
        if crear_elem is not None:
            nombre = crear_elem.find('.//nombre').text if crear_elem.find('.//nombre') is not None else ''
            matricula = crear_elem.find('.//matricula').text if crear_elem.find('.//matricula') is not None else ''
            carrera = crear_elem.find('.//carrera').text if crear_elem.find('.//carrera') is not None else ''
            
            resultado = crear_alumno(nombre, matricula, carrera)
            
            response_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tns="universidad.soap.alumnos">
    <soap:Body>
        <tns:crear_alumnoResponse>
            <tns:crear_alumnoResult>{resultado}</tns:crear_alumnoResult>
        </tns:crear_alumnoResponse>
    </soap:Body>
</soap:Envelope>"""
            
            return Response(response_xml, mimetype='text/xml')
        
        # Verificar si es listar_alumnos
        print("DEBUG - Buscando listar_alumnos...")
        listar_elem = body.find('.//tns:listar_alumnos', namespaces)
        if listar_elem is None:
            listar_elem = body.find('.//listar_alumnos')
        print(f"DEBUG - listar_elem encontrado: {listar_elem is not None}")
        if listar_elem is not None:
            nombres = listar_alumnos()
            
            nombres_xml = '\n            '.join([f'<tns:string>{nombre}</tns:string>' for nombre in nombres])
            
            response_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tns="universidad.soap.alumnos">
    <soap:Body>
        <tns:listar_alumnosResponse>
            <tns:listar_alumnosResult>
            {nombres_xml}
            </tns:listar_alumnosResult>
        </tns:listar_alumnosResponse>
    </soap:Body>
</soap:Envelope>"""
            
            return Response(response_xml, mimetype='text/xml')
        
        # Método no encontrado
        error_xml = """<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <soap:Body>
        <soap:Fault>
            <faultcode>soap:Client</faultcode>
            <faultstring>Método no encontrado</faultstring>
        </soap:Fault>
    </soap:Body>
</soap:Envelope>"""
        
        return Response(error_xml, mimetype='text/xml', status=500)
        
    except Exception as e:
        error_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <soap:Body>
        <soap:Fault>
            <faultcode>soap:Server</faultcode>
            <faultstring>Error: {str(e)}</faultstring>
        </soap:Fault>
    </soap:Body>
</soap:Envelope>"""
        
        return Response(error_xml, mimetype='text/xml', status=500)


@app.route('/soap', methods=['GET'])
def wsdl():
    """
    Retorna el WSDL del servicio
    """
    wsdl_content = """<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="http://schemas.xmlsoap.org/wsdl/"
             xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/"
             xmlns:tns="universidad.soap.alumnos"
             xmlns:xsd="http://www.w3.org/2001/XMLSchema"
             targetNamespace="universidad.soap.alumnos"
             name="AlumnosService">
    
    <types>
        <xsd:schema targetNamespace="universidad.soap.alumnos">
            <xsd:element name="crear_alumno">
                <xsd:complexType>
                    <xsd:sequence>
                        <xsd:element name="nombre" type="xsd:string"/>
                        <xsd:element name="matricula" type="xsd:string"/>
                        <xsd:element name="carrera" type="xsd:string"/>
                    </xsd:sequence>
                </xsd:complexType>
            </xsd:element>
            <xsd:element name="crear_alumnoResponse">
                <xsd:complexType>
                    <xsd:sequence>
                        <xsd:element name="crear_alumnoResult" type="xsd:string"/>
                    </xsd:sequence>
                </xsd:complexType>
            </xsd:element>
            <xsd:element name="listar_alumnos">
                <xsd:complexType>
                    <xsd:sequence/>
                </xsd:complexType>
            </xsd:element>
            <xsd:element name="listar_alumnosResponse">
                <xsd:complexType>
                    <xsd:sequence>
                        <xsd:element name="listar_alumnosResult" type="tns:ArrayOfString"/>
                    </xsd:sequence>
                </xsd:complexType>
            </xsd:element>
            <xsd:complexType name="ArrayOfString">
                <xsd:sequence>
                    <xsd:element name="string" type="xsd:string" minOccurs="0" maxOccurs="unbounded"/>
                </xsd:sequence>
            </xsd:complexType>
        </xsd:schema>
    </types>
    
    <message name="crear_alumnoRequest">
        <part name="parameters" element="tns:crear_alumno"/>
    </message>
    <message name="crear_alumnoResponse">
        <part name="parameters" element="tns:crear_alumnoResponse"/>
    </message>
    <message name="listar_alumnosRequest">
        <part name="parameters" element="tns:listar_alumnos"/>
    </message>
    <message name="listar_alumnosResponse">
        <part name="parameters" element="tns:listar_alumnosResponse"/>
    </message>
    
    <portType name="AlumnosServicePortType">
        <operation name="crear_alumno">
            <input message="tns:crear_alumnoRequest"/>
            <output message="tns:crear_alumnoResponse"/>
        </operation>
        <operation name="listar_alumnos">
            <input message="tns:listar_alumnosRequest"/>
            <output message="tns:listar_alumnosResponse"/>
        </operation>
    </portType>
    
    <binding name="AlumnosServiceBinding" type="tns:AlumnosServicePortType">
        <soap:binding transport="http://schemas.xmlsoap.org/soap/http"/>
        <operation name="crear_alumno">
            <soap:operation soapAction="crear_alumno"/>
            <input>
                <soap:body use="literal"/>
            </input>
            <output>
                <soap:body use="literal"/>
            </output>
        </operation>
        <operation name="listar_alumnos">
            <soap:operation soapAction="listar_alumnos"/>
            <input>
                <soap:body use="literal"/>
            </input>
            <output>
                <soap:body use="literal"/>
            </output>
        </operation>
    </binding>
    
    <service name="AlumnosService">
        <port name="AlumnosServicePort" binding="tns:AlumnosServiceBinding">
            <soap:address location="http://localhost:5001/soap"/>
        </port>
    </service>
</definitions>"""
    
    return Response(wsdl_content, mimetype='text/xml')


@app.route('/')
def index():
    """
    Página de inicio con información del servicio
    """
    return """
    <html>
        <head>
            <title>API SOAP - Gestión de Alumnos</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; }
                h1 { color: #333; }
                .info { background-color: #f0f0f0; padding: 20px; border-radius: 5px; }
                code { background-color: #e0e0e0; padding: 2px 5px; border-radius: 3px; }
            </style>
        </head>
        <body>
            <h1>🎓 API SOAP - Sistema de Gestión de Alumnos</h1>
            <div class="info">
                <h2>Información del Servicio</h2>
                <p><strong>Endpoint SOAP:</strong> <code>http://localhost:5001/soap</code></p>
                <p><strong>WSDL:</strong> <code>http://localhost:5001/soap?wsdl</code></p>
                
                <h3>Métodos disponibles:</h3>
                <ul>
                    <li><strong>crear_alumno</strong>(nombre, matricula, carrera) - Crea un nuevo alumno</li>
                    <li><strong>listar_alumnos</strong>() - Lista todos los alumnos registrados</li>
                </ul>
                
                <h3>Estado:</h3>
                <p style="color: green;">✓ Servicio activo y funcionando (Versión Compatible Python 3.12)</p>
            </div>
        </body>
    </html>
    """


if __name__ == '__main__':
    print("=" * 60)
    print("🚀 Iniciando API SOAP - Sistema de Gestión de Alumnos")
    print("   (Versión Compatible con Python 3.12)")
    print("=" * 60)
    print(f"📍 Endpoint SOAP: http://localhost:5001/soap")
    print(f"📄 WSDL: http://localhost:5001/soap")
    print("=" * 60)
    print("✅ Credenciales MySQL configuradas correctamente")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5001)
