"""
API SOAP para gestión de Alumnos - Proyecto Universitario
Autor: Sistema de gestión universitaria
Descripción: Servicio SOAP que permite crear y listar alumnos en una base de datos MySQL
"""

from spyne import Application, rpc, ServiceBase, Unicode, Array
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from flask import Flask
import mysql.connector
from mysql.connector import Error

# ============================================================================
# CONFIGURACIÓN DE CREDENCIALES DE BASE DE DATOS
# ============================================================================
# ⚠️ IMPORTANTE: Modifica estas variables con tus credenciales locales de MySQL
DB_HOST = 'localhost'
DB_USER = 'root'              # ← Usuario de MySQL
DB_PASSWORD = ''              # ← Contraseña de MySQL (vacía)
DB_NAME = 'universidad_db'
# ============================================================================


def obtener_conexion():
    """
    Establece y retorna una conexión a la base de datos MySQL
    """
    try:
        conexion = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,           # ← Usuario de MySQL
            password=DB_PASSWORD,   # ← Contraseña de MySQL
            database=DB_NAME
        )
        if conexion.is_connected():
            return conexion
    except Error as e:
        print(f"Error al conectar a MySQL: {e}")
        return None


class AlumnosService(ServiceBase):
    """
    Servicio SOAP para gestión de Alumnos
    """
    
    @rpc(Unicode, Unicode, Unicode, _returns=Unicode)
    def crear_alumno(ctx, nombre, matricula, carrera):
        """
        Crea un nuevo alumno en la base de datos
        
        Parámetros:
            nombre (str): Nombre completo del alumno
            matricula (str): Matrícula única del alumno
            carrera (str): Carrera que cursa el alumno
            
        Retorna:
            str: Mensaje de confirmación o error
        """
        conexion = obtener_conexion()
        
        if conexion is None:
            return "Error: No se pudo conectar a la base de datos"
        
        try:
            cursor = conexion.cursor()
            query = "INSERT INTO Alumnos (nombre, matricula, carrera) VALUES (%s, %s, %s)"
            valores = (nombre, matricula, carrera)
            
            cursor.execute(query, valores)
            conexion.commit()
            
            mensaje = f"Alumno '{nombre}' con matrícula '{matricula}' creado exitosamente"
            
            cursor.close()
            conexion.close()
            
            return mensaje
            
        except Error as e:
            if conexion:
                conexion.close()
            return f"Error al crear alumno: {str(e)}"
    
    
    @rpc(_returns=Array(Unicode))
    def listar_alumnos(ctx):
        """
        Lista todos los alumnos registrados en la base de datos
        
        Retorna:
            list: Lista con los nombres de todos los alumnos
        """
        conexion = obtener_conexion()
        
        if conexion is None:
            return ["Error: No se pudo conectar a la base de datos"]
        
        try:
            cursor = conexion.cursor()
            query = "SELECT nombre FROM Alumnos"
            
            cursor.execute(query)
            resultados = cursor.fetchall()
            
            # Extraer solo los nombres de los resultados
            nombres = [fila[0] for fila in resultados]
            
            cursor.close()
            conexion.close()
            
            if not nombres:
                return ["No hay alumnos registrados"]
            
            return nombres
            
        except Error as e:
            if conexion:
                conexion.close()
            return [f"Error al listar alumnos: {str(e)}"]


# Crear la aplicación SOAP
soap_app = Application(
    [AlumnosService],
    tns='universidad.soap.alumnos',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

# Crear la aplicación WSGI
wsgi_app = WsgiApplication(soap_app)

# Crear la aplicación Flask
app = Flask(__name__)

# Montar la aplicación SOAP en Flask
@app.route('/soap', methods=['POST'])
def soap_service():
    """
    Endpoint para el servicio SOAP
    """
    return wsgi_app


@app.route('/')
def index():
    """
    Página de inicio con información del servicio
    """
    return """
    <html>
        <head>
            <title>API SOAP - Gestión de Alumnos</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; }
                h1 { color: #333; }
                .info { background-color: #f0f0f0; padding: 20px; border-radius: 5px; }
                code { background-color: #e0e0e0; padding: 2px 5px; border-radius: 3px; }
            </style>
        </head>
        <body>
            <h1>🎓 API SOAP - Sistema de Gestión de Alumnos</h1>
            <div class="info">
                <h2>Información del Servicio</h2>
                <p><strong>Endpoint SOAP:</strong> <code>http://localhost:5000/soap</code></p>
                <p><strong>WSDL:</strong> <code>http://localhost:5000/soap?wsdl</code></p>
                
                <h3>Métodos disponibles:</h3>
                <ul>
                    <li><strong>crear_alumno</strong>(nombre, matricula, carrera) - Crea un nuevo alumno</li>
                    <li><strong>listar_alumnos</strong>() - Lista todos los alumnos registrados</li>
                </ul>
                
                <h3>Estado:</h3>
                <p style="color: green;">✓ Servicio activo y funcionando</p>
            </div>
        </body>
    </html>
    """


if __name__ == '__main__':
    print("=" * 60)
    print("🚀 Iniciando API SOAP - Sistema de Gestión de Alumnos")
    print("=" * 60)
    print(f"📍 Endpoint SOAP: http://localhost:5000/soap")
    print(f"📄 WSDL: http://localhost:5000/soap?wsdl")
    print("=" * 60)
    print("⚠️  Asegúrate de haber configurado las credenciales de MySQL")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)
