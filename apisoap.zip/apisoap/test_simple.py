"""
Cliente de Prueba Simple para API SOAP - Gestión de Alumnos
Este script prueba los métodos SOAP usando requests directamente
"""

import requests
import xml.etree.ElementTree as ET

# URL del servicio SOAP
SOAP_URL = 'http://localhost:5001/soap'

def listar_alumnos():
    """
    Prueba el método listar_alumnos
    """
    soap_request = """<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tns="universidad.soap.alumnos">
    <soap:Body>
        <tns:listar_alumnos/>
    </soap:Body>
</soap:Envelope>"""
    
    headers = {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'listar_alumnos'
    }
    
    response = requests.post(SOAP_URL, data=soap_request, headers=headers)
    
    return response.text


def crear_alumno(nombre, matricula, carrera):
    """
    Prueba el método crear_alumno
    """
    soap_request = f"""<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tns="universidad.soap.alumnos">
    <soap:Body>
        <tns:crear_alumno>
            <nombre>{nombre}</nombre>
            <matricula>{matricula}</matricula>
            <carrera>{carrera}</carrera>
        </tns:crear_alumno>
    </soap:Body>
</soap:Envelope>"""
    
    headers = {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'crear_alumno'
    }
    
    response = requests.post(SOAP_URL, data=soap_request, headers=headers)
    
    return response.text


def main():
    print("=" * 70)
    print("🧪 CLIENTE DE PRUEBA - API SOAP ALUMNOS")
    print("=" * 70)
    print()
    
    # PRUEBA 1: Listar alumnos
    print("-" * 70)
    print("🔍 PRUEBA 1: Listar alumnos existentes")
    print("-" * 70)
    
    try:
        response = listar_alumnos()
        print("✅ Respuesta recibida:")
        
        # Parsear la respuesta
        root = ET.fromstring(response)
        nombres = root.findall('.//{universidad.soap.alumnos}string')
        
        if not nombres:
            # Intentar sin namespace
            nombres = root.findall('.//string')
        
        print(f"   Total de alumnos: {len(nombres)}")
        for i, nombre_elem in enumerate(nombres, 1):
            print(f"   {i}. {nombre_elem.text}")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    print()
    
    # PRUEBA 2: Crear un nuevo alumno
    print("-" * 70)
    print("➕ PRUEBA 2: Crear un nuevo alumno")
    print("-" * 70)
    
    nuevo_nombre = "Ana Martínez"
    nueva_matricula = "A888"
    nueva_carrera = "Ingeniería Civil"
    
    print(f"📝 Datos del nuevo alumno:")
    print(f"   Nombre: {nuevo_nombre}")
    print(f"   Matrícula: {nueva_matricula}")
    print(f"   Carrera: {nueva_carrera}")
    print()
    
    try:
        response = crear_alumno(nuevo_nombre, nueva_matricula, nueva_carrera)
        
        # Parsear la respuesta
        root = ET.fromstring(response)
        resultado = root.find('.//{universidad.soap.alumnos}crear_alumnoResult')
        
        if resultado is None:
            resultado = root.find('.//crear_alumnoResult')
        
        if resultado is not None:
            print(f"✅ {resultado.text}")
        else:
            print("✅ Alumno creado (respuesta recibida)")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    print()
    
    # PRUEBA 3: Listar alumnos después de crear
    print("-" * 70)
    print("🔍 PRUEBA 3: Listar alumnos después de la creación")
    print("-" * 70)
    
    try:
        response = listar_alumnos()
        
        # Parsear la respuesta
        root = ET.fromstring(response)
        nombres = root.findall('.//{universidad.soap.alumnos}string')
        
        if not nombres:
            nombres = root.findall('.//string')
        
        print(f"✅ Total de alumnos: {len(nombres)}")
        for i, nombre_elem in enumerate(nombres, 1):
            print(f"   {i}. {nombre_elem.text}")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    print()
    
    # PRUEBA 4: Intentar crear alumno duplicado
    print("-" * 70)
    print("⚠️  PRUEBA 4: Intentar crear alumno con matrícula duplicada")
    print("-" * 70)
    
    try:
        response = crear_alumno("Otro Alumno", nueva_matricula, "Otra Carrera")
        
        # Parsear la respuesta
        root = ET.fromstring(response)
        resultado = root.find('.//{universidad.soap.alumnos}crear_alumnoResult')
        
        if resultado is None:
            resultado = root.find('.//crear_alumnoResult')
        
        if resultado is not None:
            print(f"📝 Resultado: {resultado.text}")
    except Exception as e:
        print(f"❌ Error esperado: {e}")
    
    print()
    print("=" * 70)
    print("✅ PRUEBAS COMPLETADAS")
    print("=" * 70)


if __name__ == '__main__':
    main()
