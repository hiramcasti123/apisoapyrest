import mysql.connector

# CONFIGURA TUS DATOS AQUI IGUAL QUE EN EL OTRO ARCHIVO
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASSWORD = ''  # <--- Pon tu contraseña aquí si tienes
DB_NAME = 'universidad_db'

try:
    # Conectar
    conn = mysql.connector.connect(
        host=DB_HOST, user=DB_USER, password=DB_PASSWORD, database=DB_NAME
    )
    cursor = conn.cursor()
    print("✅ Conectado a la BD.")

    # 1. Crear Tabla Calificaciones
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS calificaciones (
        id INT AUTO_INCREMENT PRIMARY KEY,
        matricula_alumno VARCHAR(20),
        materia VARCHAR(50),
        calificacion DECIMAL(5,2)
    )
    """)
    print("✅ Tabla 'calificaciones' creada.")

    # 2. Insertar datos de prueba
    cursor.execute("""
    INSERT INTO calificaciones (matricula_alumno, materia, calificacion) 
    VALUES ('A001', 'Matematicas', 9.5), ('A001', 'Historia', 8.0);
    """)
    conn.commit()
    print("✅ Datos de prueba insertados.")

except Exception as e:
    print(f"❌ Error: {e}")
finally:
    if 'conn' in locals() and conn.is_connected():
        conn.close()