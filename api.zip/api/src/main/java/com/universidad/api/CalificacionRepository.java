package com.universidad.api;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CalificacionRepository extends JpaRepository<Calificacion, Long> {
    // Aquí puedes agregar métodos de consulta personalizados si los necesitas
    // Por ejemplo:
    // List<Calificacion> findByMatriculaAlumno(String matriculaAlumno);
    // List<Calificacion> findByMateria(String materia);
}
